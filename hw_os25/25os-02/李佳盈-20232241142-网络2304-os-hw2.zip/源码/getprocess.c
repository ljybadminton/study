#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
int main(){
    pid_t my_pid;
    my_pid=getpid();
    printf("My process id is %d\n",my_pid);
    return 0;
}